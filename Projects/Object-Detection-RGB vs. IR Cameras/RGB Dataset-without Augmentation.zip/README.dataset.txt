# IR_CAM > 2024-06-20 9:03pm
https://universe.roboflow.com/saba-djtxy/ir_cam

Provided by a Roboflow user
License: CC BY 4.0

