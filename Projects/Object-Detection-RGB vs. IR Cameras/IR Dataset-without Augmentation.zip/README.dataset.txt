# IR_CAM_I > 2024-06-20 9:05pm
https://universe.roboflow.com/saba-djtxy/ir_cam_i

Provided by a Roboflow user
License: CC BY 4.0

